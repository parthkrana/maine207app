  schedule = {
    	"regular":[
    		{"period":"No School ATM ", "start": 0, "end": 445 },
    		{"period":"Flap", "start": 445, "end": 465 },
    		{"period":"1", "start": 465, "end": 510 },
    		{"period":"1 - 2A Passing", "start": 510, "end":515},
    		{"period":"2A", "start": 515, "end": 535 },
    		{"period":"2A - 2B Passing", "start": 535, "end":540},
    		{"period":"2B", "start": 540, "end": 560 },
    		{"period":"2B - 3A Passing", "start": 560, "end":565},
    		{"period":"3A", "start": 565, "end": 585 },
    		{"period":"3A - 3B Passing", "start": 585, "end":590},
    		{"period":"3B", "start": 590, "end": 610 },
    		{"period":"Announcements", "start": 610, "end": 615 },
    		{"period":"3B - 4A Passing", "start": 615, "end":620},
    		{"period":"4A", "start": 620, "end": 640 },
    		{"period":"4A - 4B Passing", "start": 640, "end":645},
    		{"period":"4B", "start": 645, "end": 665 },
    		{"period":"4B - 5A Passing", "start": 665, "end":670},
    		{"period":"5A", "start": 670, "end": 690 },
    		{"period":"5A - 5B Passing", "start": 690, "end":695},
    		{"period":"5B", "start": 695, "end": 715 },
    		{"period":"5B - 6A Passing", "start": 715, "end":720},
    		{"period":"6A", "start": 720, "end": 740 },
    		{"period":"6A - 6B Passing", "start": 740, "end":745},
    		{"period":"6B", "start": 745, "end": 765 },
    		{"period":"6B - 7A Passing", "start": 765, "end":770},
    		{"period":"7A", "start": 770, "end": 790 },
    		{"period":"7A - 7B Passing", "start": 790, "end":795},
    		{"period":"7B", "start": 795, "end": 815 },
    		{"period":"7B - 8A Passing", "start": 815, "end":820},
    		{"period":"8A", "start": 820, "end": 840 },
    		{"period":"8A - 8B Passing", "start": 840, "end":845},
    		{"period":"8B", "start": 845, "end": 865 },
    		{"period":"8B - 9 Passing", "start": 865, "end":870},
    		{"period":"9", "start": 870, "end": 915 },
    		{"period":"No School ATM", "start": 915, "end": 1440 }
    	],

    	"lateStart":[
    		{"period":"No School ATM ", "start": 0, "end": 515 },
    		{"period":"Flap", "start": 515, "end": 528 },
    		{"period":"1", "start": 528, "end": 564 },
    		{"period":"1 - 2B Passing", "start": 564, "end": 569 },
    		{"period":"2A", "start": 569, "end": 585 },
    		{"period":"2A - 2B Passing", "start": 585, "end": 590 },
    		{"period":"2B", "start": 590, "end": 606 },
    		{"period":"2B - 3A Passing", "start": 606, "end": 611 },
    		{"period":"3A", "start": 611, "end": 627 },
    		{"period":"3A - 3B Passing", "start": 627, "end": 632 },
    		{"period":"3B", "start": 632, "end": 648 },
    		{"period":"3B - 4A Passing", "start": 648, "end": 653 },
    		{"period":"4A", "start": 653, "end": 671 },
    		{"period":"4A - 4B Passing", "start": 671, "end": 676 },
    		{"period":"4B", "start": 676, "end": 694 },
    		{"period":"4B - 5A Passing", "start": 694, "end": 699 },
    		{"period":"5A", "start": 699, "end": 717 },
    		{"period":"5A - 5B Passing", "start": 717, "end": 722 },
    		{"period":"5B", "start": 722, "end": 740 },
    		{"period":"5B - 6A Passing", "start": 740, "end": 745 },
    		{"period":"6A", "start": 745, "end": 763 },
    		{"period":"6A - 6B Passing", "start": 763, "end": 768 },
    		{"period":"6B", "start": 768, "end": 786 },
    		{"period":"6B - 7A Passing", "start": 786, "end": 791 },
    		{"period":"7A", "start": 791, "end": 809 },
    		{"period":"7A - 7B Passing", "start": 809, "end": 814 },
    		{"period":"7B", "start": 814, "end": 832 },
    		{"period":"7B - 8A Passing", "start": 832, "end": 837 },
    		{"period":"8A", "start": 837, "end": 853 },
    		{"period":"8A - 8B Passing", "start": 853, "end": 858 },
    		{"period":"8B", "start": 858, "end": 874 },
    		{"period":"8B - 9 Passing", "start": 874, "end": 879 },
    		{"period":"9", "start": 879, "end": 915 },
    		{"period":"No School ATM", "start": 915, "end": 1440 }
    	]};
       //starts the clock, updates the date sorts the day type, classifies the time according to AM and PM, identifies what needs to be printed with id "txt"


(function startTime() {
    'use strict';

    angular
        .module('angle', [
          var today = new Date();
          var h = today.getHours();
          var m = today.getMinutes();
          var s = today.getSeconds();
          var d = today.getDay();
          var dtype;

          if (d == 1 || d == 2 || d == 4 || d == 5)
          dtype = schedule.regular;
          if (d == 3)
          dtype = schedule.lateStart;

          var mil = new Date();
          var o = mil.getHours();
          var ampm = " " ;

          var totaltime = 60*h + m;

          if (o > 12 && o  < 24)
           ampm = "PM";
          if (o >=  0 && o < 13)
           ampm = "AM";

          h = changeTo12hr(h);
          m = checkTime(m);
          s = checkTime(s);


     if (totaltime >= 445 && totaltime <= 915)
     {
          document.getElementById('txt').innerHTML =
          h + ":" + m +  ' ' + ampm + "<br />" + updatePeriod(totaltime, dtype) + "<br />" + updatePeriod(totaltime, dtype) + " ends in " + End(totaltime, dtype) +" minutes";
     }
     else
     {
       document.getElementById('txt').innerHTML =
       h + ":" + m +  ' ' + ampm + "<br />" + updatePeriod(totaltime, dtype);
     }
          var t = setTimeout(startTime, 500);


       }
       //updates period
       function updatePeriod(totaltime, dtype)
       {
           for (var findp in dtype)
           {
             if (totaltime >= dtype[findp].start && totaltime < dtype[findp].end)
               {
                console.log("first called " + totaltime);
                return dtype[findp].period;
               }
              }
           return "No School"
           }

       function End(totaltime, dtype)
       {
         for (var fp in dtype)
         {
           if (totaltime >= dtype[fp].start && totaltime < dtype[fp].end)
             {
              console.log("first called " + totaltime);
              return (dtype[fp].end - totaltime);
             }
       }
     }
     function checkTime(i) {
        if (i < 10) {i = "0" + i};
        return i;
     }
     function changeTo12hr(h){
      if(h>12) return (h-12);
      if (h == 0) return 12;
      return h;
     }
     //easter eggs
     var counterCode = 0;
     function cheatcode(){
       counterCode++;
       if(counterCode > 8)
         document.getElementById('site').innerHTML = "<img src=''>";

        ]);
})();
