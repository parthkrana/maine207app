(function() {
    'use strict';

    angular
        .module('app.material', [
            'ngMaterial'
          ]);
})();